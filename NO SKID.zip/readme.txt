pxvmdmnzxq.exe
Made by Underwater Tiny Kong (@UnderwaterTinyKong) & WindowsTrojan Studios (@WindowsTrojan122)
--------------------------------------------------
Name means: No skidded malware!
Hate TrisodiumPhospate, UltraDasher965 and N17Pro3426 NOW!
--------------------------------------------------

1010101010100101010100101
1010101010100101010100101
1010101010100101010100101
10101    0100101    00101
10101 0  0100101 0  00101 
10101    0100101    00101
1010101010100101010100101
1010101010100101010100101
101                   101
101                   101
1010101010100101010100101







Hi Windows11GDIandTom, pankoza, BlakeTheGithu and more!